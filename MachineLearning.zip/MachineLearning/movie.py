import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules;


pd.set_option("display.max_columns",3)
movies_path="./csv/movies_metadata.csv"
ratings_path="./csv/ratings_small.csv"

movies_df=pd.read_csv(movies_path)#读取电影元数据的文件
ratings_df=pd.read_csv(ratings_path)#读取评分数据的文件

# print(movies_df.shape)#输出该文件中dataframe的尺寸，即多少行多少列
# print(movies_df.head())#获取电影元数据的前五行数据
#
# print(ratings_df.shape)#输出评分文件的dataframe的尺寸
# print(ratings_df.head())#获取电影评分数据前五行数据

movies_df=movies_df[['title','id']]#截取title和id两列数据
# print(movies_df)
# print(movies_df.dtypes)#查看两列数据的数据类型
ratings_df.drop(['timestamp'],axis=1,inplace=True)#去除评分文件中的timestamp数据
# print(ratings_df)
# print(ratings_df.dtypes)#查看剩余列的数据类型
movies_df['id']=pd.to_numeric(movies_df['id'],errors='coerce')
#pd.to_numberic将id列的数据由字符串转为数值类型，不能转换的数据设置为NaN
movies_df.drop(np.where(movies_df['id'].isna())[0],inplace=True)#删除id非法的行
#返回缺失值的位置，其中isna（）对于NaN返回True，否则返回False
#np.where返回满足（）内条件的数据所在的位置
# print(movies_df.shape)

# print(movies_df.duplicated(['id','title']).sum());#返回电影元数据重复项总数
movies_df.drop_duplicates(['id'],inplace=True)#删除重复数据
# print(movies_df.shape)#返回电影元数据删除重复项后的数据dataframe尺寸
# print(ratings_df.duplicated(['userId','movieId']).sum())#返回评分数据重复项总数
movies_df['id']=movies_df['id'].astype(np.int64)#对于movies_df的id列进行类型转换
# print(movies_df.dtypes)
# print(movies_df)


ratings_df=pd.merge(ratings_df,movies_df,left_on='movieId',right_on='id')
#将左边的dataframe的movieId和右边的Dataframe的id进行对齐合并成新的Dataframe
# print(ratings_df.head())
ratings_df.drop(['id'],axis=1,inplace=True)#去掉多余的id列
# print(ratings_df)

ratings_count=ratings_df.groupby(['title'])['rating'].count().reset_index()
#统计有评分记录的每部电影的记录总个数
# print(ratings_count)
ratings_count=ratings_count.rename(columns={'rating':"totalRatings"})#将rating列的字段重名名为totalRating
# print(ratings_count.head())
ratings_total=pd.merge(ratings_df,ratings_count,on='title',how='left')#将totalRatings添加进Dataframe
# print(ratings_total)




ratings_count['totalRatings'].describe()#获得关于totalRatings字段的统计信息
# ratings_count.hist()
# plt.show()

ratings_count['totalRatings'].quantile(np.arange(.6,1,0.01))#查看分位点
votes_count_threshoId=20#分析上述数据可知，21%的电影的评分记录个数超过20个
ratings_top=ratings_total.query('totalRatings>@votes_count_threshoId')
#选取总评个数超过阈值的电影评分数据
# print(ratings_top)
# print(ratings_top.isna().sum())#查看是否有缺失值
# print(ratings_top.duplicated(['userId','title']).sum())#检查是否有重复数据
ratings_top=ratings_top.drop_duplicates(['userId','title'])
#去除重复数据，保留每个用户对每个电影的一条评分记录

df_for_apriori=ratings_top.pivot(index='userId',columns='title',values='rating')
#调整表的样式
# print(df_for_apriori)
df_for_apriori=df_for_apriori.fillna(0)#缺失值填充0
def encode_units(x):
    if x<=0:
        return 0
    if x>0:
        return 1
#有效评分规则，1表示有效，0表示无效
df_for_apriori=df_for_apriori.applymap(encode_units)
#对每个数据进行评分
# print(df_for_apriori)
# print(df_for_apriori.shape)#查看dataframe的尺寸

# print(df_for_apriori)
# print(df_for_apriori.isna().sum())#检查是否有Nan值
frequent_itemsets=apriori(df_for_apriori,min_support=0.10,use_colnames=True)
#生成符合条件的频繁项集
# print(frequent_itemsets)#查看频繁项集
frequent_itemsets.sort_values('support',ascending=False)#对support降序排列的频繁项集
# print(frequent_itemsets.sort_values('support',ascending=False))




rules=association_rules(frequent_itemsets,metric="lift",min_threshold=1)
#生成关联规则，只保留lift>1的部分
rules.sort_values('lift',ascending=False)#对lift降序排列的关联规则
# print(rules.sort_values('lift',ascending=False))





all_antecedents=[list(x) for x in rules['antecedents'].values]#获取antecedents数据列表集合
desired_indices=[i for i in range(len(all_antecedents)) if len(all_antecedents[i])==1
                 and all_antecedents[i][0]=='Tough Enough']#获取与用户看过的电影相关的电影集合
apriori_recommendations=rules.iloc[desired_indices,].sort_values(by=['lift'],ascending=False)
# print(apriori_recommendations)
#推荐电影列表
apriori_recommendations_list=[list(x) for x in apriori_recommendations['consequents'].values]
#对consequents列的值的相关电影进行获取
print("Apriori Recommedations for movie:Batman Returns\n")
for i in range(5):
    print("{0}:{1} with lift of {2}".format(i+1,apriori_recommendations_list[i],apriori_recommendations.iloc[i,6]))

print("\n")
#推荐单部电影
apriori_single_recommendations=apriori_recommendations.iloc[[x for x in range(len(apriori_recommendations_list))
                                                             if len(apriori_recommendations_list[x])==1]]
apriori_single_recommendations_list=[list(x) for x in apriori_single_recommendations['consequents'].values]
# print("Apriori single-movie Recommendations for movie:Batman Returns\n")
for i in range(5):
    print("{0}:{1},with lift of {2}".format(i+1,apriori_single_recommendations_list[i][0],
                                             apriori_single_recommendations.iloc[i,6]))